//
//  Distance.swift
//  FindMyCat
//
//  Created by Sahas Chitlange on 7/6/23.
//

import Foundation

func convertMetersToFeet(meters: Float) -> Float {
    let feet = meters * 3.28084
    return feet
}
